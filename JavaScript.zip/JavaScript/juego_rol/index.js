/*
Opcional:
  3.- Crea la clase personaje con las siguientes características:
  - Nombre
  - Vida
  - Ataque
  - Defensa
  - Velocidad
  - Nivel
  - Experiencia

  crea los siguientes métodos:
  - Atacar
  - Defender
  - Subir de nivel
  - Ganar experiencia
  - Morir

  Crea la clase enemigo que se extiende de la clase personaje pero que contiene ademas
  - Recompensa
  - Tipo de enemigo
  - Faccion

  Crea la funcion pelear que reciba dos personajes y que simule una pelea entre ellos

  fecha de entrega: 19/02/2024
  */